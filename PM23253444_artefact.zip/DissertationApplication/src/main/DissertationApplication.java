
package main;

import view.MenuForm;

/**
 * @author Sam
 */
public class DissertationApplication {

    /** Main class to open up Menu form
     *
     * @param args
     */
    public static void main(String[] args) {
       MenuForm menu = new MenuForm();
        menu.setVisible(true);
    }
    
}
